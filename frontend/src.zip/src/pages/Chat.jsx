import {
  useEffect,
  useRef,
  useState,
} from "react";

import axios from "axios";

import "../App.css";

const API_URL =
  "http://localhost:8080/api";

function Chat() {

  /* =====================================================
     STATE
     ===================================================== */

  const [conversations, setConversations] =
    useState([]);

  const [selectedConversationId, setSelectedConversationId] =
    useState(null);

  const [messages, setMessages] =
    useState([]);

  const [question, setQuestion] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  const [loadingMessages, setLoadingMessages] =
    useState(false);

  const [error, setError] =
    useState("");

  const messagesEndRef =
    useRef(null);

  const inputRef =
    useRef(null);


  /* =====================================================
     LOAD CONVERSATIONS
     ===================================================== */

  const loadConversations = async () => {

    try {

      const response = await axios.get(
        `${API_URL}/conversations`
      );

      const data = Array.isArray(response.data)
        ? response.data
        : [];

      setConversations(data);

    } catch (err) {

      console.error(
        "Failed to load conversations:",
        err
      );

    }

  };


  /* =====================================================
     LOAD MESSAGES
     ===================================================== */

  const loadMessages = async (
    conversationId
  ) => {

    if (!conversationId) {
      setMessages([]);
      return;
    }

    try {

      setLoadingMessages(true);

      const response = await axios.get(
        `${API_URL}/conversations/${conversationId}/messages`
      );

      const data = Array.isArray(response.data)
        ? response.data
        : [];

      setMessages(data);

      setSelectedConversationId(
        conversationId
      );

    } catch (err) {

      console.error(
        "Failed to load messages:",
        err
      );

      setError(
        "Unable to load this conversation."
      );

    } finally {

      setLoadingMessages(false);

    }

  };


  /* =====================================================
     INITIAL LOAD
     ===================================================== */

  useEffect(() => {

    loadConversations();

  }, []);


  /* =====================================================
     NEW CHAT EVENT
     ===================================================== */

  useEffect(() => {

    const handleNewChat = () => {
      createNewChat();
    };

    window.addEventListener(
      "doclock:new-chat",
      handleNewChat
    );

    return () => {

      window.removeEventListener(
        "doclock:new-chat",
        handleNewChat
      );

    };

  }, []);


  /* =====================================================
     SCROLL TO BOTTOM
     ===================================================== */

  useEffect(() => {

    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth",
    });

  }, [messages, loading]);


  /* =====================================================
     CREATE NEW CHAT
     ===================================================== */

  const createNewChat = () => {

    setSelectedConversationId(null);

    setMessages([]);

    setQuestion("");

    setError("");

    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);

  };


  /* =====================================================
     SEND MESSAGE
     ===================================================== */

  const sendMessage = async () => {

    const trimmedQuestion =
      question.trim();

    if (!trimmedQuestion || loading) {
      return;
    }

    setError("");

    const userMessage = {
      id: `temp-user-${Date.now()}`,
      role: "USER",
      content: trimmedQuestion,
      createdAt: new Date().toISOString(),
    };

    setMessages((current) => [
      ...current,
      userMessage,
    ]);

    setQuestion("");

    try {

      setLoading(true);

      /*
       * IMPORTANT
       *
       * Your existing /api/chat endpoint
       * accepts the question.
       *
       * If there is already a conversation,
       * send its ID so the backend continues
       * that conversation.
       */

      const payload = {
        question: trimmedQuestion,
      };

      if (selectedConversationId) {
        payload.conversationId =
          selectedConversationId;
      }


      const response = await axios.post(
        `${API_URL}/chat`,
        payload
      );


      const data = response.data;


      /*
       * Backend response:
       *
       * {
       *   answer: "...",
       *   sources: [...]
       * }
       */


      const assistantMessage = {
        id: `temp-assistant-${Date.now()}`,
        role: "ASSISTANT",
        content:
          data?.answer ||
          "I couldn't generate an answer.",
        createdAt:
          new Date().toISOString(),

        sources:
          data?.sources || [],
      };


      setMessages((current) => [
        ...current,
        assistantMessage,
      ]);


      /*
       * Reload conversations because
       * backend may create a new conversation
       * automatically.
       */

      await loadConversations();


    } catch (err) {

      console.error(
        "Chat error:",
        err
      );

      /*
       * Remove optimistic user message
       * if request failed.
       */

      setMessages((current) =>
        current.filter(
          (message) =>
            message.id !==
            userMessage.id
        )
      );

      setError(
        err?.response?.data?.message ||
        "Sorry, I couldn't process your question. Please try again."
      );

    } finally {

      setLoading(false);

      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);

    }

  };


  /* =====================================================
     ENTER KEY
     ===================================================== */

  const handleKeyDown = (event) => {

    if (
      event.key === "Enter" &&
      !event.shiftKey
    ) {

      event.preventDefault();

      sendMessage();

    }

  };


  /* =====================================================
     DELETE CONVERSATION
     ===================================================== */

  const deleteConversation = async (
    event,
    conversationId
  ) => {

    event.stopPropagation();

    const confirmed =
      window.confirm(
        "Delete this conversation?"
      );

    if (!confirmed) return;


    try {

      await axios.delete(
        `${API_URL}/conversations/${conversationId}`
      );


      setConversations((current) =>
        current.filter(
          (conversation) =>
            conversation.id !==
            conversationId
        )
      );


      if (
        selectedConversationId ===
        conversationId
      ) {

        createNewChat();

      }

    } catch (err) {

      console.error(
        "Delete conversation error:",
        err
      );

      setError(
        "Failed to delete conversation."
      );

    }

  };


  /* =====================================================
     FORMAT DATE
     ===================================================== */

  const formatConversationDate = (
    date
  ) => {

    if (!date) return "";

    return new Date(
      date
    ).toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
      }
    );

  };


  /* =====================================================
     RENDER SIDEBAR HISTORY
     ===================================================== */

  useEffect(() => {

    const sidebar =
      document.getElementById(
        "sidebar-conversations"
      );

    if (!sidebar) return;


    sidebar.innerHTML = "";


    if (conversations.length === 0) {

      const empty =
        document.createElement(
          "div"
        );

      empty.className =
        "no-conversations";

      empty.textContent =
        "No conversations yet.";

      sidebar.appendChild(empty);

      return;

    }


    conversations.forEach(
      (conversation) => {

        const item =
          document.createElement(
            "button"
          );

        item.className =
          "conversation-item";

        if (
          conversation.id ===
          selectedConversationId
        ) {

          item.classList.add(
            "active"
          );

        }


        const icon =
          document.createElement(
            "span"
          );

        icon.className =
          "conversation-icon";

        icon.textContent = "💬";


        const content =
          document.createElement(
            "span"
          );

        content.className =
          "conversation-item-content";


        const title =
          document.createElement(
            "span"
          );

        title.className =
          "conversation-title";

        title.textContent =
          conversation.title ||
          "New conversation";


        const date =
          document.createElement(
            "span"
          );

        date.className =
          "conversation-date";

        date.textContent =
          formatConversationDate(
            conversation.updatedAt ||
            conversation.createdAt
          );


        content.appendChild(title);

        content.appendChild(date);

        item.appendChild(icon);

        item.appendChild(content);


        item.onclick = () =>
          loadMessages(
            conversation.id
          );


        sidebar.appendChild(item);

      }
    );

  }, [
    conversations,
    selectedConversationId,
  ]);


  /* =====================================================
     CHAT WELCOME
     ===================================================== */

  const showWelcome =
    messages.length === 0 &&
    !loadingMessages;


  /* =====================================================
     UI
     ===================================================== */

  return (

    <div className="chat-page">

      {/* ===============================================
          CHAT CONTENT
          =============================================== */}

      <div className="chat-content">

        {showWelcome ? (

          <div className="chat-welcome">

            <div className="chat-welcome-icon">
              🔐
            </div>

            <p className="chat-welcome-label">
              YOUR PRIVATE AI ASSISTANT
            </p>

            <h2>
              Ask anything about
              <br />
              your documents.
            </h2>

            <p className="chat-welcome-description">
              DocLock searches your uploaded
              documents and generates answers
              using your private knowledge base.
            </p>


            {/* QUICK QUESTIONS */}

            <div className="quick-questions">

              <button
                onClick={() => {
                  setQuestion(
                    "What certification did I complete?"
                  );

                  inputRef.current?.focus();
                }}
              >
                🎓 What certification did I complete?
              </button>


              <button
                onClick={() => {
                  setQuestion(
                    "What is in my documents?"
                  );

                  inputRef.current?.focus();
                }}
              >
                📄 What is in my documents?
              </button>

            </div>

          </div>

        ) : (

          <div className="messages-container">

            {messages.map(
              (message) => (

                <div
                  key={message.id}
                  className={`message-row ${
                    message.role === "USER"
                      ? "user-message"
                      : "assistant-message"
                  }`}
                >

                  <div className="message-avatar">

                    {message.role === "USER"
                      ? "👤"
                      : "🔐"}

                  </div>


                  <div className="message-body">

                    <div className="message-name">

                      {message.role === "USER"
                        ? "You"
                        : "DocLock AI"}

                    </div>


                    <div className="message-bubble">

                      {message.content}

                    </div>


                    {/* SOURCES */}

                    {message.sources &&
                      message.sources.length >
                        0 && (

                        <div className="message-sources">

                          <div className="sources-title">
                            Sources
                          </div>


                          {message.sources.map(
                            (source, index) => (

                              <div
                                className="source-card"
                                key={
                                  source.id ||
                                  index
                                }
                              >

                                <span>
                                  📄
                                </span>

                                <div>

                                  <strong>
                                    Document #
                                    {source.documentId}
                                  </strong>

                                  <small>
                                    Chunk{" "}
                                    {source.chunkNumber}
                                  </small>

                                </div>


                                {source.similarity !=
                                  null && (

                                  <span className="similarity">
                                    {(
                                      source.similarity *
                                      100
                                    ).toFixed(1)}
                                    %
                                  </span>

                                )}

                              </div>

                            )
                          )}

                        </div>

                      )}

                  </div>

                </div>

              )
            )}


            {loading && (

              <div className="message-row assistant-message">

                <div className="message-avatar">
                  🔐
                </div>

                <div className="message-body">

                  <div className="message-name">
                    DocLock AI
                  </div>

                  <div className="typing-indicator">

                    <span></span>
                    <span></span>
                    <span></span>

                  </div>

                </div>

              </div>

            )}


            <div
              ref={messagesEndRef}
            />

          </div>

        )}

      </div>


      {/* ===============================================
          ERROR
          =============================================== */}

      {error && (

        <div className="chat-error">
          {error}
        </div>

      )}


      {/* ===============================================
          INPUT
          =============================================== */}

      <div className="chat-input-area">

        <div className="chat-input-wrapper">

          <textarea
            ref={inputRef}
            value={question}
            onChange={(event) =>
              setQuestion(
                event.target.value
              )
            }
            onKeyDown={handleKeyDown}
            placeholder="Ask something about your documents..."
            rows={1}
            disabled={loading}
          />


          <button
            className="send-button"
            onClick={sendMessage}
            disabled={
              loading ||
              !question.trim()
            }
            title="Send"
          >

            {loading
              ? "..."
              : "↑"}

          </button>

        </div>


        <p className="chat-input-hint">
          DocLock answers using your private
          document knowledge base.
        </p>

      </div>

    </div>

  );
}

export default Chat;