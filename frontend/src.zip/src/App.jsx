import { useEffect, useRef, useState } from "react";
import axios from "axios";
import "./App.css";
import Chat from "./pages/Chat";

const API_URL = "http://localhost:8080/api";

function App() {
  const [documents, setDocuments] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(false);

  const [currentPage, setCurrentPage] = useState("documents");

  const fileInputRef = useRef(null);

  /* =====================================================
     FETCH DOCUMENTS
     ===================================================== */

  const fetchDocuments = async () => {
    try {
      setLoading(true);

      const response = await axios.get(
        `${API_URL}/documents`
      );

      setDocuments(response.data);
    } catch (error) {
      console.error(
        "Failed to fetch documents:",
        error
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  /* =====================================================
     SELECT FILE
     ===================================================== */

  const selectFile = (file) => {
    if (!file) return;

    if (file.type !== "application/pdf") {
      alert("Only PDF files are allowed.");
      return;
    }

    setSelectedFile(file);
  };

  const handleFileChange = (event) => {
    selectFile(event.target.files[0]);
  };

  /* =====================================================
     DRAG & DROP
     ===================================================== */

  const handleDragOver = (event) => {
    event.preventDefault();
    setDragActive(true);
  };

  const handleDragLeave = () => {
    setDragActive(false);
  };

  const handleDrop = (event) => {
    event.preventDefault();
    setDragActive(false);

    const file = event.dataTransfer.files[0];

    selectFile(file);
  };

  const [dragActive, setDragActive] = useState(false);

  /* =====================================================
     UPLOAD
     ===================================================== */

  const uploadDocument = async () => {
    if (!selectedFile) {
      alert("Please select a PDF first.");
      return;
    }

    const formData = new FormData();

    formData.append("file", selectedFile);

    try {
      setUploading(true);

      await axios.post(
        `${API_URL}/documents/upload`,
        formData
      );

      alert("Document uploaded successfully!");

      setSelectedFile(null);

      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }

      await fetchDocuments();

    } catch (error) {
      console.error(
        "Upload error:",
        error
      );

      if (error.response) {
        console.error(
          "Backend response:",
          error.response.data
        );
      }

      alert(
        "Upload failed. Check the browser console."
      );

    } finally {
      setUploading(false);
    }
  };

  /* =====================================================
     DELETE DOCUMENT
     ===================================================== */

  const deleteDocument = async (id) => {
    const confirmed = window.confirm(
      "Delete this document?"
    );

    if (!confirmed) return;

    try {
      await axios.delete(
        `${API_URL}/documents/${id}`
      );

      setDocuments((current) =>
        current.filter(
          (document) => document.id !== id
        )
      );

    } catch (error) {
      console.error(
        "Delete error:",
        error
      );

      alert(
        "Failed to delete document."
      );
    }
  };

  /* =====================================================
     FORMAT SIZE
     ===================================================== */

  const formatSize = (bytes) => {
    if (!bytes) return "0 KB";

    if (bytes < 1024) {
      return `${bytes} B`;
    }

    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }

    return `${(
      bytes /
      (1024 * 1024)
    ).toFixed(1)} MB`;
  };

  /* =====================================================
     FORMAT DATE
     ===================================================== */

  const formatDate = (date) => {
    if (!date) return "";

    return new Date(date).toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );
  };

  /* =====================================================
     LOGOUT
     ===================================================== */

  const handleLogout = () => {
    const confirmed = window.confirm(
      "Are you sure you want to logout?"
    );

    if (!confirmed) return;

    localStorage.removeItem("isAuthenticated");

    window.location.href = "/login";
  };

  /* =====================================================
     UI
     ===================================================== */

  return (
    <div className="app">

      {/* =================================================
          SIDEBAR
          ================================================= */}

      <aside className="sidebar">

        {/* LOGO */}

        <div className="logo">

          <div className="logo-box">
            🔐
          </div>

          <div>
            <h2>DocLock</h2>

            <span>
              Personal AI Vault
            </span>
          </div>

        </div>


        {/* NAVIGATION */}

        <nav className="sidebar-nav">

          {/* DOCUMENTS */}

          <button
            className={`nav-button ${
              currentPage === "documents"
                ? "active"
                : ""
            }`}
            onClick={() =>
              setCurrentPage("documents")
            }
          >
            <span className="nav-icon">
              📁
            </span>

            <span>
              Documents
            </span>
          </button>


          {/* AI CHAT */}

          <button
            className={`nav-button ${
              currentPage === "chat"
                ? "active"
                : ""
            }`}
            onClick={() =>
              setCurrentPage("chat")
            }
          >
            <span className="nav-icon">
              🤖
            </span>

            <span>
              AI Chat
            </span>
          </button>


          {/* =============================================
              CHAT HISTORY

              ONLY visible when AI CHAT is selected
              ============================================= */}

          {currentPage === "chat" && (
            <div className="conversation-sidebar">

              <div className="conversation-header">

                <span>
                  Conversations
                </span>

                <button
                  className="new-conversation-button"
                  title="New conversation"
                  onClick={() =>
                    window.dispatchEvent(
                      new CustomEvent(
                        "doclock:new-chat"
                      )
                    )
                  }
                >
                  +
                </button>

              </div>

              {/* Chat component controls the actual
                  conversation list */}

              <div
                id="sidebar-conversations"
                className="conversation-list"
              >
                <span className="no-conversations">
                  Open a chat to view history.
                </span>
              </div>

            </div>
          )}

        </nav>


        {/* PRIVATE VAULT */}

        <div className="privacy-box">

          <div className="privacy-title">
            🔒 Private Vault
          </div>

          <p>
            Your documents are stored
            privately on your system.
          </p>

        </div>

      </aside>


      {/* =================================================
          MAIN
          ================================================= */}

      <main className="main">

        {/* HEADER */}

        <header className="header">

          <div>

            <p className="header-label">
              {currentPage === "chat"
                ? "DOCLOCK AI"
                : "PERSONAL VAULT"}
            </p>

            <h1>
              {currentPage === "chat"
                ? "Ask your documents"
                : "My Documents"}
            </h1>

          </div>


          {/* HEADER ACTIONS */}

          <div className="header-actions">

            {currentPage === "documents" && (
              <button
                className="refresh-button"
                onClick={fetchDocuments}
              >
                ↻ Refresh
              </button>
            )}

            {currentPage === "chat" && (
              <button
                className="refresh-button"
                onClick={() =>
                  window.dispatchEvent(
                    new CustomEvent(
                      "doclock:new-chat"
                    )
                  )
                }
              >
                + New Chat
              </button>
            )}

            <button
              className="logout-navbar-button"
              onClick={handleLogout}
            >
              ↪ Logout
            </button>

          </div>

        </header>


        {/* =================================================
            DOCUMENT PAGE
            ================================================= */}

        {currentPage === "documents" && (

          <section className="content">

            {/* HERO */}

            <section className="hero">

              <div className="hero-content">

                <p className="hero-label">
                  YOUR PRIVATE KNOWLEDGE BASE
                </p>

                <h2>
                  Store your knowledge.
                  <br />

                  <span>
                    Ask your documents anything.
                  </span>
                </h2>

                <p className="hero-description">
                  Upload your documents and
                  DocLock will prepare them
                  for AI-powered search and
                  conversations.
                </p>

              </div>

              <div className="hero-symbol">
                🔐
              </div>

            </section>


            {/* UPLOAD */}

            <section className="upload-section">

              <div className="section-title">

                <h3>
                  Upload Document
                </h3>

                <p>
                  Add a PDF to your personal
                  knowledge base.
                </p>

              </div>


              <div
                className={`upload-area ${
                  dragActive
                    ? "drag-active"
                    : ""
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >

                {!selectedFile ? (

                  <>

                    <div className="upload-icon">
                      ↑
                    </div>

                    <h4>
                      Drag & drop your PDF here
                    </h4>

                    <p>
                      or choose a file from
                      your computer
                    </p>


                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="application/pdf"
                      onChange={handleFileChange}
                      hidden
                    />


                    <button
                      className="browse-button"
                      onClick={() =>
                        fileInputRef.current?.click()
                      }
                    >
                      + Browse Files
                    </button>


                    <span className="file-hint">
                      PDF files only
                    </span>

                  </>

                ) : (

                  <div className="selected-file">

                    <div className="file-icon">
                      PDF
                    </div>

                    <div className="file-details">

                      <strong>
                        {selectedFile.name}
                      </strong>

                      <span>
                        {formatSize(
                          selectedFile.size
                        )}
                      </span>

                    </div>


                    <button
                      className="remove-button"
                      onClick={() =>
                        setSelectedFile(null)
                      }
                    >
                      ×
                    </button>


                    <button
                      className="upload-button"
                      onClick={uploadDocument}
                      disabled={uploading}
                    >
                      {uploading
                        ? "Processing..."
                        : "Upload & Process"}
                    </button>

                  </div>
                )}

              </div>

            </section>


            {/* DOCUMENTS */}

            <section className="documents-section">

              <div className="documents-heading">

                <div>

                  <h3>
                    Your Documents
                  </h3>

                  <p>
                    {documents.length}{" "}
                    {documents.length === 1
                      ? "document"
                      : "documents"}{" "}
                    in your vault
                  </p>

                </div>


                <div className="count">
                  {documents.length}
                </div>

              </div>


              {loading ? (

                <div className="empty">

                  <div className="loader"></div>

                  <p>
                    Loading documents...
                  </p>

                </div>

              ) : documents.length === 0 ? (

                <div className="empty">

                  <div className="empty-icon">
                    📁
                  </div>

                  <h4>
                    Your vault is empty
                  </h4>

                  <p>
                    Upload your first PDF to
                    start building your
                    knowledge base.
                  </p>

                </div>

              ) : (

                <div className="document-grid">

                  {documents.map((document) => (

                    <div
                      className="document-card"
                      key={document.id}
                    >

                      <div className="card-top">

                        <div className="pdf-badge">
                          PDF
                        </div>

                        <button
                          className="delete-button"
                          onClick={() =>
                            deleteDocument(
                              document.id
                            )
                          }
                        >
                          🗑
                        </button>

                      </div>


                      <h4
                        className="document-name"
                        title={document.fileName}
                      >
                        {document.fileName}
                      </h4>


                      <p className="document-meta">

                        {formatSize(
                          document.fileSize
                        )}

                        {" • "}

                        {formatDate(
                          document.uploadedAt
                        )}

                      </p>


                      <div className="status">

                        <span
                          className={`status-dot ${
                            document.status?.toLowerCase()
                          }`}
                        />

                        <span>
                          {document.status ===
                          "PROCESSED"
                            ? "Ready for AI"
                            : document.status}
                        </span>

                      </div>

                    </div>

                  ))}

                </div>

              )}

            </section>

          </section>

        )}


        {/* =================================================
            CHAT PAGE
            ================================================= */}

        {currentPage === "chat" && (
          <Chat />
        )}

      </main>

    </div>
  );
}

export default App;